import pygame
import time

from core import settings


class DuelInputHandler:
    def __init__(self, scene):
        self.scene = scene

    def handle_event(self, event):
        if self.scene.phase == "result":
            if event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_ESCAPE):
                self.scene.return_to_tavern = True
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and getattr(self.scene, "result_button", pygame.Rect(0, 0, 0, 0)).collidepoint(event.pos):
                self.scene.return_to_tavern = True
            return
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self.scene.return_to_tavern = True
                return

        if event.type == pygame.MOUSEWHEEL:
            self._handle_log_scroll(event.y)
            return

        if (
            event.type != pygame.MOUSEBUTTONDOWN
            or event.button not in (1, 3)
        ):
            return

        from ui.character_card import CharacterCard
        control = CharacterCard.stat_control_at(self.scene.layout.battle_player_card, event.pos)
        if control is not None:
            stat_name, delta = control
            changed = (
                self.scene.player.add_stat(stat_name)
                if delta > 0
                else self.scene.player.remove_stat(stat_name)
            )
            if changed:
                self.scene.save_online_character()
            return

        if self.scene.phase == "resolve":
            return

        if self.scene.layout.hide_player_card_button.collidepoint(event.pos):
            self.scene.player_card_hidden = not self.scene.player_card_hidden
            self.scene.player_card_manual_open = not self.scene.player_card_hidden
            return
        if self.scene.layout.hide_enemy_card_button.collidepoint(event.pos):
            self.scene.enemy_card_hidden = not self.scene.enemy_card_hidden
            self.scene.enemy_card_manual_open = not self.scene.enemy_card_hidden
            return

        if self.scene.phase in ("draft", "planning"):
            self._handle_card_phase(event.pos, event.button)
            return

    def _handle_log_scroll(self, direction):
        current_offset = getattr(
            self.scene,
            "log_scroll_offset",
            0,
        )

        self.scene.log_scroll_offset = max(
            0,
            current_offset + (3 if direction > 0 else -3),
        )

    def _handle_card_phase(self, pos, button):
        layout = self.scene.layout
        battle = self.scene.battle
        if self.scene.phase == "draft":
            if self.scene.draft_next_side != "player":
                return
            visible_table = battle.table
            for index, card in enumerate(visible_table):
                if card.key in battle.starting_reserved_keys:
                    continue
                row_area = pygame.Rect(
                    layout.card_table.x + 20,
                    layout.card_table.y + 5 + (self.scene.renderer.card_renderer.CARD_HEIGHT + self.scene.renderer.card_renderer.GAP if index >= 5 else 0),
                    layout.card_table.width - 40,
                    self.scene.renderer.card_renderer.CARD_HEIGHT,
                )
                if self.scene.renderer.card_renderer.card_rect(row_area, 5, index % 5).collidepoint(pos):
                    battle.choose_starting_card("player", card.key)
                    self.scene.draft_next_side = "enemy"
                    self.scene.card_transfer = {
                        "card": card,
                        "started": time.monotonic(),
                        "source": self.scene.renderer.card_renderer.card_rect(row_area, 5, index % 5),
                    }
                    self.scene.phase = "draft_transfer"
                    return
            return

        if button == 1 and layout.play_cards_button.collidepoint(pos):
            battle.confirm_selection("player")
            self.scene.enemy_wait_started = time.monotonic()
            self.scene.phase = "waiting_enemy"
            return

        if button == 1:
            for index, card in enumerate(battle.selected["player"]):
                card_rect = self.scene.renderer.card_renderer.card_rect(layout.player_selected, len(battle.selected["player"]), index)
                if card_rect.collidepoint(pos):
                    self.scene.card_return_transfer = {
                        "card": card,
                        "started": time.monotonic(),
                        "source": card_rect,
                    }
                    self.scene.phase = "card_return"
                    return

        visible_hand = [card for card in battle.hands["player"] if card not in battle.selected["player"]]
        for index, card in enumerate(visible_hand):
            hand_rect = self.scene.renderer.card_renderer.card_rect(layout.player_hand, len(visible_hand), index)
            if hand_rect.collidepoint(pos):
                if button == 1:
                    battle.select_card("player", card.key)
                elif button == 3:
                    battle.deselect_card("player", card.key)
                return

