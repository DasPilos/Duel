from pathlib import Path
import time

import pygame

from core import settings
from ui.hud import draw_text, draw_button, update_and_draw_floating_texts

from ui.character_card import CharacterCard
from ui.renderers.card_area import CardAreaRenderer


class DuelRenderer:
    def __init__(self, scene):
        self.scene = scene
        self.layout = scene.layout

        self.player_card = CharacterCard()
        self.enemy_card = CharacterCard()

        self.card_renderer = CardAreaRenderer(
            scene,
            self.layout,
        )
        self.background = None
        background_path = Path(__file__).resolve().parent.parent / "assets" / "combat" / "background.png"
        try:
            source = pygame.image.load(str(background_path)).convert()
            self.background = pygame.transform.smoothscale(source, (settings.WIDTH, settings.HEIGHT))
        except (pygame.error, OSError):
            self.background = None
        self.hit_placeholder = None
        placeholder_path = Path(__file__).resolve().parent.parent / "assets" / "combat" / "hit_placeholder.png"
        try:
            self.hit_placeholder = pygame.image.load(str(placeholder_path)).convert_alpha()
        except (pygame.error, OSError):
            self.hit_placeholder = None

    def draw(self, screen):
        if self.background is None or screen.get_size() != self.background.get_size():
            screen.fill((16, 18, 28))
        else:
            screen.blit(self.background, (0, 0))

        if self.scene.phase == "result":
            self.draw_result(screen)
            return

        self.draw_header(screen)

        if self.scene.phase in ("intro_table", "intro_deck", "draft_reveal", "draft", "draft_transfer", "enemy_transfer", "strength_transfer", "draft_cleanup", "planning", "waiting_enemy", "clash", "damage", "deck_shuffle", "card_draw", "card_return"):
            self.card_renderer.draw(screen)

        elif self.scene.phase == "resolve":
            self.draw_resolve_overlay(screen)


        if self.scene.chat is not None:
            self.scene.chat.draw(screen)

        if not self.scene.player_card_hidden:
            self.player_card.update_from_fighter(self.scene.player, title="ИГРОК", kind="player")
            self.player_card.draw(screen, self.layout.battle_player_card, border_color=(80, 180, 120), editable=False, opponent=self.scene.enemy, card_preview=self.scene.battle.selected["player"])

        if not self.scene.enemy_card_hidden:
            self.enemy_card.update_from_fighter(self.scene.enemy, title="ПРОТИВНИК", kind="enemy")
            self.enemy_card.draw(screen, self.layout.battle_enemy_card, border_color=(210, 80, 80), opponent=self.scene.player)

        draw_button(screen, self.layout.hide_player_card_button, "+" if self.scene.player_card_hidden else "-", self.scene.small_font)
        draw_button(screen, self.layout.hide_enemy_card_button, "+" if self.scene.enemy_card_hidden else "-", self.scene.small_font)

        update_and_draw_floating_texts(
            screen,
            self.scene.active_floating_texts,
        )

        self.scene.profile_overlay.draw(
            screen,
            opponent=self.scene.player,
            show_counterpart=False,
        )

    def draw_result(self, screen):
        scene = self.scene
        panel = pygame.Rect(360, 100, 1200, 820)
        pygame.draw.rect(screen, (25, 27, 38), panel, border_radius=10)
        pygame.draw.rect(screen, (170, 135, 70), panel, width=2, border_radius=10)
        outcome = scene.battle.outcome()
        title = {"win": "ПОБЕДА", "loss": "ПОРАЖЕНИЕ", "draw": "НИЧЬЯ"}.get(outcome, "БОЙ ОКОНЧЕН")
        title_color = (110, 235, 120) if outcome == "win" else (235, 110, 100) if outcome == "loss" else (255, 220, 120)
        title_surface = scene.big.render(title, True, title_color)
        screen.blit(title_surface, title_surface.get_rect(center=(panel.centerx, panel.y + 55)))
        draw_text(screen, scene.small_font, f"Победитель: {scene.battle.winner_name() or 'Ничья'}", panel.x + 45, panel.y + 100, (220, 220, 225))
        for index, side in enumerate(("player", "enemy")):
            stats = scene.battle.stats[side]
            fighter = scene.player if side == "player" else scene.enemy
            x = panel.x + 45 + index * 580
            draw_text(screen, scene.font, fighter.name, x, panel.y + 155, (255, 220, 120))
            lines = (
                f"Критов: {stats['critical']}",
                f"Уворотов: {stats['dodges']}",
                f"Ударов прошло: {stats['hits']}",
                f"Урона нанесено: {stats['damage']}",
                f"Восстановлено: {stats['healed']} HP",
                f"Карт использовано: {stats['cards_played']}",
            )
            for line_index, line in enumerate(lines):
                draw_text(screen, scene.small_font, line, x, panel.y + 200 + line_index * 30, (215, 220, 230))
            cards = ", ".join(stats["cards"]) or "нет"
            draw_text(screen, scene.small_font, "Карты:", x, panel.y + 405, (170, 190, 210))
            for line_index in range(0, len(cards), 48):
                draw_text(screen, scene.small_font, cards[line_index:line_index + 48], x, panel.y + 435 + line_index // 48 * 24, (215, 220, 230))
        scene.result_button = pygame.Rect(panel.centerx - 160, panel.bottom - 75, 320, 45)
        draw_button(screen, scene.result_button, "В ТАВЕРНУ", scene.font, color=(75, 105, 155))

    def draw_header(self, screen):
        self.draw_turn_timer(screen)

    def draw_resolve_overlay(self, screen):
        if self.hit_placeholder is None:
            return
        image = pygame.transform.smoothscale(self.hit_placeholder, (128, 128))
        image_rect = image.get_rect(center=(960, 520))
        screen.blit(image, image_rect)

    def draw_turn_timer(self, screen):
        if self.scene.turn_deadline is None:
            return
        remaining = max(0, int(self.scene.turn_deadline - time.monotonic()))
        if remaining <= settings.TURN_WARNING_RED_SECONDS:
            color = (220, 70, 70)
        elif remaining <= settings.TURN_WARNING_YELLOW_SECONDS:
            color = (230, 190, 70)
        else:
            color = (80, 200, 120)
        bar = self.layout.turn_bar
        pygame.draw.rect(screen, (55, 58, 68), bar, border_radius=5)
        fill = bar.copy()
        fill.height = int(bar.height * remaining / settings.TURN_DECISION_SECONDS)
        fill.top = bar.bottom - fill.height
        pygame.draw.rect(screen, color, fill, border_radius=5)
        label = self.scene.small_font.render(f"Ход {remaining // 60}:{remaining % 60:02d}", True, color)
        label = pygame.transform.rotate(label, 90)
        screen.blit(label, label.get_rect(midright=(bar.left - 8, bar.centery)))

