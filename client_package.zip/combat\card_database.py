import json
import sqlite3
from dataclasses import dataclass
from pathlib import Path


DATABASE_PATH = Path(__file__).resolve().parent.parent / "cards.sqlite3"


@dataclass(frozen=True)
class Card:
    key: str
    name: str
    group_name: str
    strength_cost: int
    intuition_cost: int
    agility_cost: int
    endurance_cost: int
    effect_type: str
    effect_data: dict

    @property
    def costs(self):
        return {"strength": self.strength_cost, "intuition": self.intuition_cost, "agility": self.agility_cost, "endurance": self.endurance_cost}


BASE_CARDS = (
    ("straight_punch", "Прямой удар", "Удары", 1, 0, 0, 0, "damage", {"dice": "1d4"}),
    ("hard_hook", "Жёсткий хук", "Удары", 1, 0, 1, 0, "damage", {"dice": "1d4", "next_damage": 1}),
    ("body_shot", "Удар в корпус", "Удары", 1, 1, 0, 0, "damage", {"dice": "1d3"}),
    ("heavy_swing", "Тяжёлый замах", "Удары", 2, 0, 0, 0, "damage", {"dice": "1d6"}),
    ("short_ram", "Короткий таран", "Удары", 1, 0, 0, 1, "damage_reduce", {"dice": "1d4", "reduce": 2}),
    ("piercing_jab", "Разящий тычок", "Удары", 1, 1, 0, 0, "damage", {"dice": "1d4", "critical_bonus": 10}),
    ("jab_series", "Серия джебов", "Удары", 1, 2, 0, 0, "multi_damage", {"dice": "1d2", "hits": 2}),
    ("broken_rhythm", "Сбитый ритм", "Удары", 1, 1, 1, 0, "damage_reduce", {"dice": "1d4", "reduce": 2}),
    ("breaking_hook", "Разбивающий хук", "Удары", 2, 0, 1, 1, "damage", {"dice": "1d6", "critical_bonus_damage": 2}),
    ("crushing_elbow", "Сокрушающий локоть", "Удары", 2, 1, 0, 1, "damage", {"dice": "1d6", "dodge_reduce": 10}),
    ("bloody_blow", "Кровавый удар", "Удары", 3, 0, 0, 0, "damage_recoil", {"dice": "2d6", "recoil": 2}),
    ("blind_assault", "Слепой натиск", "Удары", 2, 1, 1, 0, "damage", {"dice": "1d8", "self_dodge_reduce": 10}),
    ("breaking_lunge", "Ломающий выпад", "Удары", 2, 1, 0, 1, "damage", {"dice": "2d4"}),
    ("crushing_blow", "Сокрушающий удар", "Удары", 3, 0, 0, 1, "damage", {"dice": "2d8"}),
    ("titan_blow", "Удар титана", "Удары", 4, 0, 0, 0, "damage", {"dice": "3d8", "single_action": True}),
    ("shadow_dodge", "Уклонение в тень", "Ловкачи", 0, 0, 3, 0, "dodge", {"bonus": 30}),
    ("light_step", "Лёгкий шаг", "Ловкачи", 0, 1, 2, 0, "dodge", {"bonus": 15, "duration": 2}),
    ("sliding_maneuver", "Скользящий манёвр", "Ловкачи", 0, 0, 3, 0, "dodge", {"bonus": 20}),
    ("dance_between_blows", "Танец между ударами", "Ловкачи", 0, 1, 2, 0, "dodge", {"bonus": 10, "duration": 2}),
    ("aim_disruption", "Срыв прицела", "Ловкачи", 0, 2, 1, 0, "dodge", {"bonus": 20}),
    ("aimed_strike", "Прицельный удар", "Критовики", 1, 2, 0, 0, "damage", {"dice": "1d4", "critical_bonus": 15}),
    ("precise_calculation", "Меткий расчёт", "Критовики", 0, 3, 1, 0, "critical", {"bonus": 25}),
    ("sharp_eye", "Острый взгляд", "Критовики", 0, 3, 0, 0, "critical", {"bonus": 15, "duration": 2}),
    ("weak_point", "Удар в слабое место", "Критовики", 1, 2, 1, 0, "damage", {"dice": "1d6", "critical_multiplier": 1.5}),
    ("focused_lunge", "Сфокусированный рывок", "Критовики", 0, 2, 2, 0, "critical", {"bonus": 20}),
    ("light_stance", "Лёгкая стойка", "Выносливость", 1, 0, 0, 2, "damage_resistance", {"ratio": 0.5}),
    ("steel_stance", "Стальная стойка", "Выносливость", 0, 0, 0, 3, "damage_resistance", {"ratio": 0.3}),
    ("stone_stance", "Каменная стойка", "Выносливость", 0, 1, 0, 3, "damage_resistance", {"ratio": 0.7, "duration": 2}),
    ("spirit_recovery", "Восстановление духа", "Выносливость", 0, 1, 0, 2, "heal", {"dice": "1d6"}),
    ("unyielding_block", "Неодолимый блок", "Выносливость", 1, 0, 0, 4, "damage_resistance", {"ratio": 0, "duration": 1}),
)


def initialize_database(path=DATABASE_PATH):
    with sqlite3.connect(path) as connection:
        connection.execute("""CREATE TABLE IF NOT EXISTS cards (
            key TEXT PRIMARY KEY, name TEXT NOT NULL, group_name TEXT NOT NULL,
            strength_cost INTEGER NOT NULL, intuition_cost INTEGER NOT NULL,
            agility_cost INTEGER NOT NULL, endurance_cost INTEGER NOT NULL,
            effect_type TEXT NOT NULL, effect_data TEXT NOT NULL,
            enabled INTEGER NOT NULL DEFAULT 1)""")
        connection.executemany(
            """INSERT OR IGNORE INTO cards
            (key, name, group_name, strength_cost, intuition_cost, agility_cost,
             endurance_cost, effect_type, effect_data)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            [(*row[:-1], json.dumps(row[-1], ensure_ascii=False)) for row in BASE_CARDS],
        )
        connection.commit()


def load_cards(path=DATABASE_PATH):
    initialize_database(path)
    with sqlite3.connect(path) as connection:
        rows = connection.execute(
            "SELECT key, name, group_name, strength_cost, intuition_cost, agility_cost, endurance_cost, effect_type, effect_data FROM cards WHERE enabled = 1 ORDER BY rowid"
        ).fetchall()
    return [Card(*row[:-1], json.loads(row[-1])) for row in rows]