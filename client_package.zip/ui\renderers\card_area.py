import time
from pathlib import Path

import pygame

from core import settings
from ui.hud import draw_button, draw_text


class CardAreaRenderer:
    CARD_WIDTH = 150
    CARD_HEIGHT = 200
    GAP = 20

    def __init__(self, scene, layout):
        self.scene = scene
        self.layout = layout
        self.battle_table_image = None
        table_path = Path(__file__).resolve().parent.parent.parent / "assets" / "combat" / "battle_table.png"
        try:
            self.battle_table_image = pygame.image.load(str(table_path)).convert()
        except (pygame.error, OSError):
            self.battle_table_image = None
        self.card_back_image = None
        back_path = Path(__file__).resolve().parent.parent.parent / "assets" / "cards" / "исходник" / "1.png"
        try:
            source = pygame.image.load(str(back_path)).convert_alpha()
            self.card_back_image = pygame.transform.smoothscale(source, (self.CARD_WIDTH, self.CARD_HEIGHT))
        except (pygame.error, OSError):
            self.card_back_image = None
        self.strength_number_images = {}
        strength_number_path = Path(__file__).resolve().parent.parent.parent / "assets" / "cards" / "numbers" / "strength"
        try:
            for value in range(6):
                image_path = strength_number_path / f"S{value}.png"
                if image_path.exists():
                    source = pygame.image.load(str(image_path)).convert_alpha()
                    self.strength_number_images[value] = pygame.transform.smoothscale(source, (40, 40))
        except (pygame.error, OSError):
            self.strength_number_images = {}
        self.endurance_number_images = {}
        endurance_number_path = Path(__file__).resolve().parent.parent.parent / "assets" / "cards" / "numbers" / "endurance"
        try:
            for value in range(6):
                image_path = endurance_number_path / f"V{value}.png"
                if image_path.exists():
                    source = pygame.image.load(str(image_path)).convert_alpha()
                    self.endurance_number_images[value] = pygame.transform.smoothscale(source, (40, 40))
        except (pygame.error, OSError):
            self.endurance_number_images = {}
        self.intuition_number_images = {}
        intuition_number_path = Path(__file__).resolve().parent.parent.parent / "assets" / "cards" / "numbers" / "intuition"
        try:
            for value in range(6):
                image_path = intuition_number_path / f"I{value}.png"
                if image_path.exists():
                    source = pygame.image.load(str(image_path)).convert_alpha()
                    self.intuition_number_images[value] = pygame.transform.smoothscale(source, (40, 40))
        except (pygame.error, OSError):
            self.intuition_number_images = {}
        self.strength_face_image = None
        strength_face_path = Path(__file__).resolve().parent.parent.parent / "assets" / "cards" / "faces" / "strength.png"
        try:
            source = pygame.image.load(str(strength_face_path)).convert_alpha()
            self.strength_face_image = pygame.transform.smoothscale(source, (self.CARD_WIDTH, self.CARD_HEIGHT))
        except (pygame.error, OSError):
            self.strength_face_image = None
        self.agility_number_images = {}
        agility_number_path = Path(__file__).resolve().parent.parent.parent / "assets" / "cards" / "numbers" / "agility"
        try:
            for value in range(6):
                image_path = agility_number_path / f"L{value}.png"
                if image_path.exists():
                    source = pygame.image.load(str(image_path)).convert_alpha()
                    self.agility_number_images[value] = pygame.transform.smoothscale(source, (40, 40))
        except (pygame.error, OSError):
            self.agility_number_images = {}

    def card_rect(self, area, count, index):
        width = min(self.CARD_WIDTH, max(50, (area.width - self.GAP * max(0, count - 1)) // max(1, count)))
        total_width = width * count + self.GAP * max(0, count - 1)
        start_x = area.centerx - total_width // 2
        height = min(self.CARD_HEIGHT, area.height)
        return pygame.Rect(start_x + index * (width + self.GAP), area.y, width, height)

    def draw(self, screen):
        battle = self.scene.battle
        if self.scene.phase != "result":
            if self.battle_table_image is not None:
                screen.blit(self.battle_table_image, self.layout.card_table)
            else:
                pygame.draw.rect(screen, (27, 31, 43), self.layout.card_table, border_radius=8)
        if self.scene.phase in ("intro_table", "intro_deck", "draft_reveal", "draft", "draft_transfer", "enemy_transfer", "strength_transfer", "draft_cleanup"):
            if self.scene.phase in ("intro_table", "intro_deck"):
                visible_table = []
            elif self.scene.phase == "draft_reveal":
                elapsed = time.monotonic() - self.scene.draft_reveal_started
                visible_table = []
            else:
                visible_table = battle.table
            pygame.draw.rect(screen, (125, 111, 76), self.layout.card_table, 2, border_radius=8)
            if self.scene.phase != "intro_table":
                self._draw_deck(screen, battle)
            draw_text(screen, self.scene.font, "СТАРТОВЫЙ ДРАФТ", self.layout.card_table.x + 20, self.layout.card_table.y + 12, (230, 210, 150))
            message = "Возврат в колоду..." if self.scene.phase == "draft_cleanup" else "Выберите до трёх карт"
            draw_text(screen, self.scene.small_font, message, self.layout.card_table.right - 220, self.layout.card_table.y + 16, (170, 170, 170))
            if self.scene.phase == "draft_cleanup":
                elapsed = time.monotonic() - self.scene.draft_cleanup_started
                progress = min(1.0, max(0.0, elapsed / settings.DRAFT_CLEANUP_SECONDS))
                self._draw_deck(screen, battle)
                for index, card in enumerate(battle.table):
                    source_area = pygame.Rect(
                        self.layout.card_table.x + 20,
                        self.layout.card_table.y + 5 + (self.CARD_HEIGHT + self.GAP if index >= 5 else 0),
                        self.layout.card_table.width - 40,
                        self.CARD_HEIGHT,
                    )
                    source = self.card_rect(source_area, 5, index % 5)
                    center_x = int(source.centerx + (self.layout.deck_rect.centerx - source.centerx) * progress)
                    center_y = int(source.centery + (self.layout.deck_rect.centery - source.centery) * progress)
                    moving_area = pygame.Rect(center_x - self.CARD_WIDTH // 2, center_y - self.CARD_HEIGHT // 2, self.CARD_WIDTH, self.CARD_HEIGHT)
                    self._draw_cards(screen, [card], moving_area, [])
                visible_table = []
            row_area = pygame.Rect(self.layout.card_table.x + 20, self.layout.card_table.y + 5, self.layout.card_table.width - 40, self.CARD_HEIGHT)
            if self.scene.phase == "draft_reveal":
                self._draw_reveal_cards(screen, battle.table, elapsed, row_area)
            else:
                self._draw_cards(screen, visible_table[:5], row_area, [])
            row_area.y += self.CARD_HEIGHT + self.GAP
            if self.scene.phase != "draft_reveal":
                self._draw_cards(screen, visible_table[5:], row_area, [])
            enemy_hand = list(battle.hands["enemy"])
            player_hand = list(battle.hands["player"])
            if self.scene.phase == "enemy_transfer" and self.scene.enemy_card_transfer is not None:
                enemy_hand.remove(self.scene.enemy_card_transfer["card"])
            if self.scene.phase == "draft_transfer" and self.scene.card_transfer is not None:
                player_hand.remove(self.scene.card_transfer["card"])
            self._draw_cards(screen, enemy_hand, self.layout.enemy_hand, enemy_hand, highlight_available=False)
            self._draw_cards(screen, player_hand, self.layout.player_hand, player_hand, highlight_available=False)
            if self.scene.phase == "draft_transfer" and self.scene.card_transfer is not None:
                transfer = self.scene.card_transfer
                target = self.card_rect(self.layout.player_hand, len(battle.hands["player"]), len(battle.hands["player"]) - 1)
                progress = min(1.0, max(0.0, (time.monotonic() - transfer["started"]) / settings.CARD_MOVE_SECONDS))
                center_x = int(transfer["source"].centerx + (target.centerx - transfer["source"].centerx) * progress)
                center_y = int(transfer["source"].centery + (target.centery - transfer["source"].centery) * progress)
                moving_area = pygame.Rect(center_x - self.CARD_WIDTH // 2, center_y - self.CARD_HEIGHT // 2, self.CARD_WIDTH, self.CARD_HEIGHT)
                self._draw_cards(screen, [transfer["card"]], moving_area, [])
            if self.scene.phase == "strength_transfer" and self.scene.card_transfer is not None:
                transfer = self.scene.card_transfer
                target_area = self.layout.player_hand if transfer["target_side"] == "player" else self.layout.enemy_hand
                hand = battle.hands[transfer["target_side"]]
                target = self.card_rect(target_area, len(hand) + 1, len(hand))
                progress = min(1.0, max(0.0, (time.monotonic() - transfer["started"]) / settings.CARD_MOVE_SECONDS))
                center_x = int(transfer["source"].centerx + (target.centerx - transfer["source"].centerx) * progress)
                center_y = int(transfer["source"].centery + (target.centery - transfer["source"].centery) * progress)
                moving_area = pygame.Rect(center_x - self.CARD_WIDTH // 2, center_y - self.CARD_HEIGHT // 2, self.CARD_WIDTH, self.CARD_HEIGHT)
                self._draw_cards(screen, [transfer["card"]], moving_area, [])
            if self.scene.phase == "enemy_transfer" and self.scene.enemy_card_transfer is not None:
                transfer = self.scene.enemy_card_transfer
                target = self.card_rect(self.layout.enemy_hand, len(battle.hands["enemy"]), len(battle.hands["enemy"]) - 1)
                progress = min(1.0, max(0.0, (time.monotonic() - transfer["started"]) / settings.CARD_MOVE_SECONDS))
                center_x = int(transfer["source"].centerx + (target.centerx - transfer["source"].centerx) * progress)
                center_y = int(transfer["source"].centery + (target.centery - transfer["source"].centery) * progress)
                moving_area = pygame.Rect(center_x - self.CARD_WIDTH // 2, center_y - self.CARD_HEIGHT // 2, self.CARD_WIDTH, self.CARD_HEIGHT)
                self._draw_cards(screen, [transfer["card"]], moving_area, [])

        else:
            if self.battle_table_image is None:
                pygame.draw.rect(screen, (27, 31, 43), self.layout.card_table, border_radius=8)
            pygame.draw.rect(screen, (125, 111, 76), self.layout.card_table, 2, border_radius=8)
            draw_text(screen, self.scene.small_font, "БОЕВОЙ СТОЛ", self.layout.card_table.x + 20, self.layout.card_table.y + 12, (170, 175, 190))
            self._draw_deck(screen, battle)
            visible_hand = [card for card in battle.hands["player"] if card not in battle.selected["player"]]
            self._draw_cards(screen, visible_hand, self.layout.player_hand, [], highlight_available=True)
            enemy_hand = [card for card in battle.hands["enemy"] if card not in battle.selected["enemy"]]
            self._draw_cards(screen, enemy_hand, self.layout.enemy_hand, [], highlight_available=False)
            self._draw_cards(screen, battle.selected["player"], self.layout.player_selected, battle.selected["player"], highlight_available=False)
            draw_button(screen, self.layout.play_cards_button, "ЗАКОНЧИТЬ ХОД", self.scene.small_font, color=(180, 130, 60))
        if self.scene.phase in ("waiting_enemy", "clash", "damage", "deck_shuffle", "card_return"):
            self._draw_cards(screen, battle.selected["enemy"], self.layout.enemy_selected, battle.selected["enemy"], highlight_available=False)
            self._draw_cards(screen, battle.selected["player"], self.layout.player_selected, battle.selected["player"], highlight_available=False)
        if self.scene.phase == "clash":
            progress = min(1.0, max(0.0, (time.monotonic() - self.scene.clash_started) / settings.ATTACK_ANIMATION_SECONDS))
            player_area = self.layout.player_selected.move(int((self.layout.card_table.right - self.layout.player_selected.right) * progress), 0)
            enemy_area = self.layout.enemy_selected.move(-int((self.layout.enemy_selected.left - self.layout.card_table.left) * progress), 0)
            self._draw_cards(screen, battle.selected["player"], player_area, battle.selected["player"], highlight_available=False)
            self._draw_cards(screen, battle.selected["enemy"], enemy_area, battle.selected["enemy"], highlight_available=False)
        if self.scene.phase == "card_return" and self.scene.card_return_transfer is not None:
            transfer = self.scene.card_return_transfer
            target = self.card_rect(self.layout.player_hand, len(battle.hands["player"]), len(battle.hands["player"]) - 1)
            progress = min(1.0, max(0.0, (time.monotonic() - transfer["started"]) / settings.CARD_MOVE_SECONDS))
            center_x = int(transfer["source"].centerx + (target.centerx - transfer["source"].centerx) * progress)
            center_y = int(transfer["source"].centery + (target.centery - transfer["source"].centery) * progress)
            moving_area = pygame.Rect(center_x - self.CARD_WIDTH // 2, center_y - self.CARD_HEIGHT // 2, self.CARD_WIDTH, self.CARD_HEIGHT)
            self._draw_cards(screen, [transfer["card"]], moving_area, [])
        if self.scene.phase == "card_draw" and self.scene.draw_transfer is not None:
            transfer = self.scene.draw_transfer
            target_area = self.layout.player_hand if transfer["side"] == "player" else self.layout.enemy_hand
            hand = battle.hands[transfer["side"]]
            target = self.card_rect(target_area, len(hand) + 1, len(hand))
            progress = min(1.0, max(0.0, (time.monotonic() - transfer["started"]) / settings.CARD_MOVE_SECONDS))
            center_x = int(self.layout.deck_rect.centerx + (target.centerx - self.layout.deck_rect.centerx) * progress)
            center_y = int(self.layout.deck_rect.centery + (target.centery - self.layout.deck_rect.centery) * progress)
            self._draw_moving_card(screen, transfer["card"], center_x, center_y, progress)
        self._draw_points(screen, battle.action_points["player"], self.layout.player_points, "")
        self._draw_points(screen, battle.action_points["enemy"], self.layout.enemy_points, "")

    def _draw_reveal_cards(self, screen, cards, elapsed, first_row):
        for index, card in enumerate(cards[:10]):
            start = 1.0 + index * settings.DRAFT_CARD_DELAY_SECONDS
            if elapsed < start:
                continue
            progress = min(1.0, (elapsed - start) / settings.CARD_MOVE_SECONDS)
            row = first_row if index < 5 else first_row.move(0, self.CARD_HEIGHT + self.GAP)
            target = self.card_rect(row, 5, index % 5)
            center_x = int(self.layout.deck_rect.centerx + (target.centerx - self.layout.deck_rect.centerx) * progress)
            center_y = int(self.layout.deck_rect.centery + (target.centery - self.layout.deck_rect.centery) * progress)
            self._draw_moving_card(screen, card, center_x, center_y, progress)

    def _draw_moving_card(self, screen, card, center_x, center_y, progress):
        """Draw a card flying from the deck while flipping around its vertical axis."""
        flip_progress = min(1.0, max(0.0, progress))
        width_scale = abs(2.0 * flip_progress - 1.0)
        width = max(2, int(self.CARD_WIDTH * width_scale))
        rect = pygame.Rect(0, 0, width, self.CARD_HEIGHT)
        rect.center = (center_x, center_y)
        if flip_progress < 0.5:
            self._draw_card_back(screen, rect)
        else:
            self._draw_card_front_scaled(screen, card, rect)

    def _draw_card_back(self, screen, rect):
        if self.card_back_image is not None and rect.width == self.CARD_WIDTH and rect.height == self.CARD_HEIGHT:
            screen.blit(self.card_back_image, rect)
            pygame.draw.rect(screen, (190, 170, 110), rect, 2, border_radius=6)
            return
        pygame.draw.rect(screen, (57, 63, 88), rect, border_radius=6)
        pygame.draw.rect(screen, (190, 170, 110), rect, 2, border_radius=6)
        inner = rect.inflate(-12, -12)
        pygame.draw.rect(screen, (43, 48, 70), inner, 2, border_radius=4)
        if rect.width > 12:
            pygame.draw.line(screen, (190, 170, 110), inner.topleft, inner.bottomright, 1)
            pygame.draw.line(screen, (190, 170, 110), inner.topright, inner.bottomleft, 1)

    def _draw_card_front_scaled(self, screen, card, rect):
        if card.strength_cost > 0 and self.strength_face_image is not None:
            image = pygame.transform.smoothscale(self.strength_face_image, rect.size)
            screen.blit(image, rect)
        else:
            pygame.draw.rect(screen, (48, 53, 70), rect, border_radius=6)
        pygame.draw.rect(screen, (190, 170, 110), rect, 2, border_radius=6)
        if rect.width < 20:
            return
        self._draw_card_name(screen, card.name, rect)
        self._draw_card_costs(screen, card, rect)

    def _draw_deck(self, screen, battle):
        rect = self.layout.deck_rect
        for offset in (8, 5, 2):
            self._draw_card_back(screen, rect.move(-offset, -offset))
        title = self.scene.small_font.render("КОЛОДА", True, (225, 205, 145))
        screen.blit(title, title.get_rect(center=(rect.centerx, rect.bottom + 18)))
        count = self.scene.small_font.render(str(len(battle.deck)), True, (220, 220, 225))
        screen.blit(count, count.get_rect(center=(rect.centerx, rect.bottom + 42)))

    def _draw_points(self, screen, points, rect, title):
        if title:
            draw_text(screen, self.scene.small_font, title, rect.x, rect.y, (210, 210, 210))
        labels = (
            ("С", "strength", settings.STRENGTH_COLOR, self.strength_number_images),
            ("И", "intuition", settings.INTUITION_COLOR, self.intuition_number_images),
            ("Л", "agility", settings.AGILITY_COLOR, self.agility_number_images),
            ("В", "endurance", settings.ENDURANCE_COLOR, self.endurance_number_images),
        )
        for index, (label, key, color, images) in enumerate(labels):
            value = points[key]
            image = images.get(value)
            if image is not None:
                screen.blit(image, image.get_rect(midtop=(rect.x + index * 120 + 20, rect.y + 18)))
            else:
                draw_text(screen, self.scene.small_font, f"{label}: {value}", rect.x + index * 120, rect.y + 25, color)

    def _draw_cards(self, screen, cards, area, selected, highlight_available=False):
        selected_keys = {card.key for card in selected}
        hovered_card = None
        hovered_rect = None
        for index, card in enumerate(cards):
            rect = self.card_rect(area, len(cards), index)
            is_selected = card.key in selected_keys
            if is_selected:
                color = (55, 135, 80)
            elif highlight_available and self.scene.battle.can_select("player", card):
                color = (45, 105, 68)
            else:
                color = (48, 53, 70)
            if card.strength_cost > 0 and self.strength_face_image is not None:
                screen.blit(self.strength_face_image, rect)
            else:
                pygame.draw.rect(screen, color, rect, border_radius=6)
            pygame.draw.rect(screen, (190, 170, 110), rect, 2, border_radius=6)
            self._draw_card_name(screen, card.name, rect)
            self._draw_card_costs(screen, card, rect)
            if rect.collidepoint(pygame.mouse.get_pos()):
                hovered_card = card
                hovered_rect = rect

        if hovered_card is not None:
            self._draw_card_tooltip(screen, hovered_card, hovered_rect)

    def _draw_card_tooltip(self, screen, card, card_rect):
        description = self._card_description(card)
        font = self.scene.small_font
        max_width = 300
        lines = []
        current = ""
        for word in description.split():
            candidate = f"{current} {word}".strip()
            if current and font.size(candidate)[0] > max_width - 24:
                lines.append(current)
                current = word
            else:
                current = candidate
        if current:
            lines.append(current)

        width = max(max_width, max(font.size(line)[0] for line in lines) + 24)
        height = 48 + len(lines) * font.get_linesize()
        mouse_x, mouse_y = pygame.mouse.get_pos()
        tooltip = pygame.Rect(mouse_x + 14, mouse_y + 14, width, height)
        if tooltip.right > settings.WIDTH:
            tooltip.right = mouse_x - 14
        if tooltip.bottom > settings.HEIGHT:
            tooltip.bottom = mouse_y - 14
        pygame.draw.rect(screen, (22, 25, 36), tooltip, border_radius=6)
        pygame.draw.rect(screen, (210, 185, 105), tooltip, 2, border_radius=6)
        title = font.render(card.name, True, (245, 225, 150))
        screen.blit(title, (tooltip.x + 12, tooltip.y + 10))
        for index, line in enumerate(lines):
            text = font.render(line, True, (230, 230, 235))
            screen.blit(text, (tooltip.x + 12, tooltip.y + 32 + index * font.get_linesize()))

    @staticmethod
    def _card_description(card):
        data = card.effect_data
        damage_text = f"Наносит {data.get('dice', '')} урона."
        descriptions = {
            "damage": f"Наносит {data.get('dice', '')} + Сила урона.",
            "multi_damage": f"Наносит {data.get('hits', 2)} отдельных удара по броску {data.get('dice', '')}.",
            "damage_recoil": f"Наносит урон по броску {data.get('dice', '')}. При некритическом ударе вы получаете {data.get('recoil', 0)} урона.",
            "damage_reduce": f"{damage_text} Следующая атака по вам наносит на {data.get('reduce', 0)} урона меньше.",
            "heal": f"Восстанавливает здоровье по броску {data.get('dice', '')}.",
            "dodge": f"Увеличивает уклонение на {data.get('bonus', 0)}%.",
            "critical": f"Увеличивает шанс критического удара на {data.get('bonus', 0)}%.",
            "damage_resistance": f"Снижает получаемый урон до {int(data.get('ratio', 1) * 100)}% от обычного.",
        }
        return descriptions.get(card.effect_type, "Особое действие карты.")

    def _draw_card_costs(self, screen, card, rect):
        costs = (
            (f"С {card.strength_cost}", settings.STRENGTH_COLOR, (rect.centerx, rect.top + 7), "midtop"),
            (f"В {card.endurance_cost}", settings.ENDURANCE_COLOR, (rect.centerx, rect.bottom - 7), "midbottom"),
            (f"Л {card.agility_cost}", settings.AGILITY_COLOR, (rect.left + 7, rect.centery), "midleft"),
            (f"И {card.intuition_cost}", settings.INTUITION_COLOR, (rect.right - 7, rect.centery), "midright"),
        )
        for label, color, position, anchor in costs:
            if label.startswith("С "):
                value = int(label[2:])
            else:
                value = None
            if value in self.strength_number_images:
                image = self.strength_number_images[value]
                image_rect = image.get_rect(midtop=(rect.centerx, rect.top + 5))
                screen.blit(image, image_rect)
                continue
            if label.startswith("В "):
                value = int(label[2:])
            else:
                value = None
            if value in self.endurance_number_images:
                image = self.endurance_number_images[value]
                image_rect = image.get_rect(midbottom=(rect.centerx, rect.bottom - 5))
                screen.blit(image, image_rect)
                continue
            if label.startswith("И "):
                value = int(label[2:])
            else:
                value = None
            if value in self.intuition_number_images:
                image = self.intuition_number_images[value]
                image_rect = image.get_rect(midright=(rect.right - 5, rect.centery))
                screen.blit(image, image_rect)
                continue
            if label.startswith("Л "):
                value = int(label[2:])
            else:
                value = None
            if value in self.agility_number_images:
                image = self.agility_number_images[value]
                image_rect = image.get_rect(midleft=(rect.left + 5, rect.centery))
                screen.blit(image, image_rect)
                continue
            text = self.scene.small_font.render(label, True, color)
            text_rect = text.get_rect(**{anchor: position})
            screen.blit(text, text_rect)
    def _draw_card_name(self, screen, name, rect):
        lines = name.split() or [name]
        line_height = self.scene.small_font.get_linesize()
        start_y = rect.centery - (len(lines) * line_height) // 2
        for index, line in enumerate(lines):
            text = self.scene.small_font.render(line, True, (240, 240, 240))
            screen.blit(text, text.get_rect(center=(rect.centerx, start_y + index * line_height)))